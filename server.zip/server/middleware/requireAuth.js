const jwt = require('jsonwebtoken');
const db = require('../db/db');

const requireAuth = async (req, res, next) => {
    console.log("requireAuth middleware called");

    // Extract the authorization header
    const { authorization } = req.headers;

    if (!authorization) {
        return res.status(401).json({ error: "Authorization token required" });
    }

    // Extract the token from the 'Bearer <token>' format
    const token = authorization.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: "Token not found in authorization header" });
    }

    try {
        // Verify the token and extract payload (email and passwordHash)
        const { email, passwordHash } = jwt.verify(token, process.env.SECRET);

        console.log("Authenticated email and password hash from token:", email, passwordHash);

        // Query the database to check if the user exists with the same email and password hash
        const query = 'SELECT email, password FROM users WHERE email = ? AND password = ?';
        const [rows] = await db.query(query, [email, passwordHash]);

        console.log("Database query result:", rows);

        if (rows.length === 0) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Attach the user details to the request object for downstream use
        req.user = { email: rows[0].email };

        next(); // Proceed to the next middleware or route handler
    } catch (error) {
        console.error("Error in requireAuth middleware:", error.message);
        res.status(401).json({ error: "Request is not authorized" });
    }
};

module.exports = requireAuth;
