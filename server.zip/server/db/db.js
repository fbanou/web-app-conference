const mysql = require('mysql2');

// Create a connection pool
const pool = mysql.createPool({
  host: 'localhost', // Change to your MySQL server host
  user: 'root', // Change to your MySQL username
  database: 'conference', // Change to your MySQL database name
  password: '1234567890', // Change to your MySQL password
  waitForConnections: true,
  connectionLimit: 10, // You can adjust this based on your needs
  queueLimit: 0,
});

// Export the pool for use in other modules
module.exports = pool.promise();