const db = require('../db/db');

async function checkConf(title) {

    try{
        const [rows, fields] = await db.query('SELECT * FROM conferences WHERE title = ?', [title]);

        if (rows.length > 0) {
            return 0; // this name is in the database
        } else {
            return 1; // this name is not in the database
        }
    } catch (error) {
        return 0;
        console.error('Error querying the database:', error);
        throw error; // You can handle or log the error as needed
    }
}

const insertPost = async (req, res) => {
    const { post, reviewerId, paperId, username } = req.body;

    console.log("\npaperId", paperId);
    console.log("\nreviewerId", reviewerId);

    // SQL query to insert post
    const insertSql = "INSERT INTO posts (post, reviewerId, paperId, username) VALUES (?,?,?,?)";

    try {
        // Step 1: Check if paper with the given ID exists
        const [paperCheck] = await db.query("SELECT * FROM paper WHERE paperId = ?", [paperId]);

        console.log("\npaperCheck", paperCheck);

        if (paperCheck?.length == 0) {
            return res.status(404).json({ error: "Paper with the given ID does not exist." });
        }

        // Step 2: Insert the post into the database
        const result = await db.query(insertSql, [post, reviewerId, paperId, username]);

        console.log("!!!!!!!! result: ", result);

        // Step 3: Fetch the inserted post to return it
        const [insertedPost] = await db.query("SELECT * FROM posts WHERE post = ?", [post]);

        console.log("!!!!!!!!!! insertedPost: ", insertedPost);

        res.status(200).json({ insertedPost });

    } catch (error) {
        console.log(error);
        res.status(400).json({ error: error.message });
    }
};


const getPostsbyPaperId = async (req, res) => {
    const { paperId } = req.body;

    const sql = `
        SELECT 
            posts.*,
            conferences.acronym AS conference
        FROM 
            posts
        INNER JOIN 
            conferencetopapers ON posts.paperId = conferencetopapers.paperId
        INNER JOIN 
            conferences ON conferencetopapers.conferenceId = conferences.conferenceId
        WHERE 
            posts.paperId = ?;
    `;

    try {
        //const [rows, fields] = await db.query('SELECT * FROM conferences WHERE paperId = ?', [paperId]);
        const [posts] = await db.query(sql, [paperId]);

        //if (rows.length > 0) {
        //const conference = rows[0]; // i want to get all the information of a conference

        res.status(200).json(posts);


    } catch (error) {
        console.error('Error querying the database in getPostsbyPaperId:', error);
        res.status(400).json({ error: error.message });
       // throw error; // You can handle or log the error as needed
    }
}

const getPostsbyUser = async (req, res) => {
    const { userId } = req.body;

    const sql = `
        SELECT 
            posts.*,
            conferences.acronym AS conference
        FROM 
            posts
        INNER JOIN 
            conferencetopapers ON posts.paperId = conferencetopapers.paperId
        INNER JOIN 
            conferences ON conferencetopapers.conferenceId = conferences.conferenceId
        WHERE 
            posts.reviewerId = ?;
    `;

    try {
        
        const [posts] = await db.query(sql, [userId]);

        console.log(posts);

        
        res.status(200).json(posts);
    } catch (error) {
        console.error('Error querying the database in getPostsbyUser:', error);
        res.status(400).json({ error: error.message });
    }
};


/*const getConferencesByAuthor = async (req, res) => {
    const { id } = req.params;

    console.log("id: ", id);

    var sql = "SELECT * FROM conferences WHERE author = ?";

    try {
        //const conferences = await db.query(sql, [id]);
        const [conferences] = await db.query(sql, [id]);
        console.log("@. Conferences: ", conferences);

        res.status(200).json(conferences);
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: error.message });
    }
};

const getConferenceById = async (req, res) => {
    const { id } = req.params;

    console.log("id: ", id);

    var sql = "SELECT * FROM conferences WHERE conferenceId = ?";

    try {
        //const conferences = await db.query(sql, [id]);
        const [conference] = await db.query(sql, [id]);
        console.log("@. Conference: ", conference);

        res.status(200).json(conference);
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: error.message });
    }
};*/


module.exports = { insertPost, getPostsbyPaperId, getPostsbyUser/*getConferencesByAuthor, getConferenceById*/ }