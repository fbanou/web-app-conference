const jwt = require("jsonwebtoken");
const db = require('../db/db');
const bcrypt = require("bcrypt");
const saltRounds = 10;

const createToken = (email, passwordHash) => {
    console.log("email: ", email);

    const token = jwt.sign(
        { email, passwordHash }, // Include both email and hashed password
        process.env.SECRET,
        { expiresIn: '10d' }
    );

    return token;
};


async function getByUsername(username){

    try {
        const [user] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
        console.log("user in 39 line; ", user);

        if (user) {
            return user;
        } else {
            return null; // User not found
        }
    } catch (error) {
        console.error('Error querying the database:', error);
        throw error; // You can handle or log the error as needed
    }
}

async function checkUsername(username) {

    try{
        const [rows, fields] = await db.query('SELECT * FROM users WHERE username = ?', [username]);

        console.log("rows.length-> ", rows.length);

        if (rows.length > 0) {
            console.log("This userrname is in the database!")
            return 0; // this username is in the database
        } else {
            console.log("This userrname is not in the database!")
            return 1; // this username is not in the database
        }
    } catch (error) {
        //return 0;
        console.error('Error querying the database:', error);
        throw error; // You can handle or log the error as needed
    }
}

// TAKE THE userId when Login or Register

//login user
const loginUser = async (req, res) => {
    const { username, password } = req.body;

    try {
        console.log("helloooooooo!");

        getByUsername(username)
            .then(async user => {
                if (user) {
                    // Compare provided password with the stored hash
                    const passwordMatch = await bcrypt.compare(password, user[0].password);
                    if (!passwordMatch) {
                        return res.status(400).json({ error: "Invalid password" });
                    }

                    // Create token with email and hashed password
                    const token = createToken(user[0].email, user[0].password);

                    res.status(200).json({ user, token });
                } else {
                    console.log('User not found');
                    res.status(400).json({ error: "User not found" });
                }
            })
            .catch(error => {
                res.status(400).json({ error: error.message });
            });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};



// sign up
const registerUser = async (req, res) => {
    const { firstName, lastName, email, phone, username, password, role } = req.body;

    try {
        console.log("HELLO!!!!!!!!");

        const check = await checkUsername(username);

        if (check == 0) {
            res.status(400).json({ error: "Username is already in use" });
            return;
        }

        const sql = "INSERT INTO users (firstName, lastName, email, phone, username, password, role) VALUES (?,?,?,?,?,?,?)";

        const hash = await bcrypt.hash(password, saltRounds);

        console.log(hash);

        const result = await db.query(sql, [firstName, lastName, email, phone, username, hash, role]);

        console.log("result in 154: ", result);

        const [user] = await db.query('SELECT * FROM users WHERE username = ?', [username]);

        console.log("errr: ", result, user);

        // Create token with email and hashed password
        const token = createToken(email, hash);
        console.log("token: ", token);

        res.status(200).json({ user, token });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};


const token = async (req, res) => {
    if (req.session.user) {
        res.send({ loggedIn: true, user: req.session.user });
    } else {
        res.send({ loggedIn: false });
    }
}

const getUserByUsername = async (req, res) => {
    const { id } = req.params;

    console.log("id: ", id);

    var sql = "SELECT * FROM users WHERE username = ?";

    try {
        
        const [user] = await db.query(sql, [id]);
        console.log("@. user: ", user);

        res.status(200).json(user);
    } catch (error) {
        console.log(error);
        res.status(400).json({ error: error.message });
    }
};


/********************************************************* */
const allUsers = async (req, res) => {
    try {
        const { username } = req.query;  
        if (!username) {
            return res.status(400).json({ error: "Username is required" });
        }
        else{
            console.log(username);
        }

        const conferences = await getAdminConferences(username); 
        console.log(conferences);
         if (conferences.length === 0) {
            return res.status(200).json([]);
        }

        const conferenceIds = conferences.map(conference => conference.conferenceId);
        console.log(conferenceIds);
        const [recommendations] = await db.query(
            "SELECT * FROM recommendations WHERE conferenceId IN (?)",
            [conferenceIds]  
        );
        console.log(recommendations);
         const reviewerIds = recommendations.map(rec => rec.reviewerId);
        console.log(reviewerIds);
        if (reviewerIds.length === 0) {
            return res.status(200).json([]);  
        }

        const [reviewers] = await db.query(
            "SELECT * FROM reviewers WHERE reviewerId IN (?)",
            [reviewerIds]
        );

        console.log('Reviewers:', reviewers); 

        if (reviewers.length === 0) {
            console.log('No reviewers found for the given conferences');
            return [];
        }

        const conferenceMap = {};
        conferences.forEach(conference => {
            conferenceMap[conference.conferenceId] = conference.title;
        });

        console.log("Conference Map:", conferenceMap);

        const usersWithConferences = reviewers.map(reviewer => {
             const userRecommendations = recommendations.filter(rec => rec.reviewerId === reviewer.reviewerId);

            
            const userConferences = userRecommendations.map(rec => {
                const conferenceTitle = conferenceMap[rec.conferenceId];  
                return conferenceTitle;  
            });

            return {
                ...reviewer,  
                conferenceTitles: userConferences  
            };
        });

        console.log("Users with Conference Titles:", usersWithConferences);

        res.status(200).json(usersWithConferences); 
      
    } catch (error) {
        console.error("Error fetching users:", error);
        res.status(500).json({ error: error.message });
    }
};

async function getAdminConferences(adminUsername) {
   
    const [conferences] = await db.query(
        "SELECT * FROM conferences WHERE author = ?",
        [adminUsername]  
    );
    return conferences;
}


const editUser = async (req, res) => {
    const { email, phone, username } = req.body; 
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({ error: "Invalid email format." });
    }

    try {
       
        const updateResult = await db.query(
            "UPDATE users SET email = ?, phone = ? WHERE username = ?",
            [email, phone, username] 
        );
       
        if (updateResult.affectedRows === 0) {
            return res.status(200).json({ message: "No changes made to the profile." });
        }

        
        const [updatedUserResult] = await db.query("SELECT * FROM users WHERE username = ?", [username]);

        if (!updatedUserResult || updatedUserResult.length === 0) {
            return res.status(400).json({ error: "Failed to retrieve updated user." });
        }

        const updatedUser = updatedUserResult[0];
                
                if (updatedUser.role === 'reviewer') {
                    await db.query(
                        "UPDATE reviewers SET email = ? WHERE reviewer = ?",
                        [updatedUser.email, username] 
                    );
                }
        

        
        res.status(200).json({ user: updatedUser, message: "Profile updated successfully. Please log in again." });
    } catch (error) {
        console.error("Error updating user:", error);
        res.status(400).json({ error: error.message });
    }
};

module.exports = {loginUser, registerUser, token, allUsers, editUser, getUserByUsername}