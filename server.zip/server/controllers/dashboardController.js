const db = require('../db/db');


const getTotalReviewers = async (req, res) => {
    try {
        const { username } = req.query;
        console.log(`/api/dashboard/totalReviewers?username=${username}`);

        if (!username) {
            return res.status(400).json({ error: "Username is required" });
        }

        console.log("Admin Username:", username);

    
        const conferences = await getAdminConferences(username);

        if (conferences.length === 0) {
            return res.status(200).json({ count: 0 }); 
        }

        console.log("Conferences:", conferences);


        const conferenceIds = conferences.map(conference => conference.conferenceId);


        const [recommendations] = await db.query(
            "SELECT * FROM recommendations WHERE conferenceId IN (?)",
            [conferenceIds]
        );

        if (recommendations.length === 0) {
            return res.status(200).json({ count: 0 }); 
        }

        console.log("Recommendations:", recommendations);

    
        const reviewerIds = recommendations.map(rec => rec.reviewerId);

        if (reviewerIds.length === 0) {
            return res.status(200).json({ count: 0 }); 
        }

        console.log("Reviewer IDs:", reviewerIds);

        
        const [reviewers] = await db.query(
            "SELECT COUNT(*) AS count FROM reviewers WHERE reviewerId IN (?)",
            [reviewerIds]
        );

        console.log("Total Reviewers:", reviewers[0]?.count || 0);

        res.status(200).json({ count: reviewers[0]?.count || 0 });
    } catch (error) {
        console.error("Error fetching total reviewers:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const getConferencesForReviewer = async (req, res) => {
    try {
        const { username } = req.query;
        console.log(`/api/dashboard/ConferencesForReviewer?username=${username}`);

        if (!username) {
            return res.status(400).json({ error: "Username is required" });
        }

        console.log("Reviewer Username:", username);

        const [reviewer] = await db.query(
            "SELECT * FROM reviewers WHERE reviewer = ?",
            [username]
        );

        if (reviewer.length === 0) {
            return res.status(200).json({ count: 0 });
        }

        console.log("Reviewer:", reviewer);

        const reviewerId = reviewer.map(rec => rec.reviewerId);

        const [conferences] = await db.query(
            "SELECT  COUNT(*) AS count FROM recommendations WHERE reviewerId IN (?)",
            [reviewerId]
        );

        if (conferences.length === 0) {
            return res.status(200).json({ count: 0 }); 
        }

        console.log("Total conferences:", conferences[0]?.count || 0);

        res.status(200).json({ count: conferences[0]?.count || 0 });
    } catch (error) {
        console.error("Error fetching total conferences:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const getTotalReviews = async (req, res) => {
    try {
        const { username } = req.query;
        console.log(`/api/dashboard/totalReviews?username=${username}`);

        if (!username) {
            return res.status(400).json({ error: "Username is required" });
        }

        console.log("Reviewer Username:", username);

        const [reviewer] = await db.query(
            "SELECT * FROM users WHERE username = ?",
            [username]
        );

        if (reviewer.length === 0) {
            return res.status(200).json({ count: 0 });
        }

        console.log("Reviewer:", reviewer);

        const reviewId =  reviewer.map(rec => rec.userId);

        
        const [reviews] = await db.query(
            "SELECT COUNT(*) AS count FROM posts WHERE reviewerId = ?",
            [reviewId]
        );

        console.log("Total reviews:", reviews[0]?.count || 0);

        res.status(200).json({ count: reviews[0]?.count || 0 });
    } catch (error) {
        console.error("Error fetching total reviews:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const getTotalPapers = async (req, res) => {
    try {
        const { username } = req.query;

        if (!username) {
            return res.status(400).json({ error: "Username is required" });
        }

        console.log("Admin Username:", username);

        
        const conferences = await getAdminConferences(username);

        if (conferences.length === 0) {
            return res.status(200).json({ count: 0 }); 
        }

        console.log(" for paper  Conferences:", conferences);

        
        const conferenceIds = conferences.map(conference => conference.conferenceId);

        
        const [papers] = await db.query(
            "SELECT COUNT(*) AS count FROM conferencetopapers WHERE conferenceId IN (?)",
            [conferenceIds]
        );

        console.log("Total Papers:", papers[0]?.count || 0);

        res.status(200).json({ count: papers[0]?.count || 0 });
    } catch (error) {
        console.error("Error fetching total papers:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

async function getAdminConferences(adminUsername) {
    
    const [conferences] = await db.query(
        "SELECT * FROM conferences WHERE author = ?",
        [adminUsername]  
    );
    return conferences;
}


const getTotalConferences = async (req, res) => {
    const { username } = req.query; 

    if (!username) {
        return res.status(400).json({ error: "Username is required" });
    }

    const sql = "SELECT COUNT(*) AS count FROM conferences WHERE author = ?";

    try {
        const [rows] = await db.query(sql, [username]);
        res.status(200).json({ count: rows[0].count });
    } catch (error) {
        console.error('Error fetching total conferences:', error);
        res.status(500).json({ error: "Internal server error" });
    }
};


module.exports = {
    getTotalReviewers,
    getConferencesForReviewer,
    getTotalReviews,
    getTotalPapers,
    getTotalConferences
};
