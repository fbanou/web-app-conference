require("dotenv").config();

const express = require("express");
const bodyParser = require("body-parser");
const userRoutes = require("./routes/user");
const userConferences = require("./routes/conference");
const userReviewer = require("./routes/reviewer");
const userPaper = require("./routes/paper")
const userPost = require("./routes/post")
const userRecommendation = require("./routes/recommendation")
const userDashboard = require("./routes/dashboard")
const cors = require('cors');

// express app
const app = express();
const path = require('path');
const mysql = require("mysql");

app.use(cors());

// middleware
app.use(express.json());

app.use((req, res, next) => {
  console.log(req.path, req.method)
  next()
});

// routes
app.use("/api/user", userRoutes);
app.use("/api/conference", userConferences);
app.use("/api/reviewer", userReviewer);
app.use("/api/paper", userPaper);
app.use("/api/post", userPost);
app.use("/api/recommendation", userRecommendation);
app.use("/api/dashboard", userDashboard);

app.listen(5000, function() {
    console.log("Server started on port 5000!");
});