const express = require("express");

// Controller functions
const {
    getTotalReviewers,
    getTotalReviews,
    getTotalPapers,
    getConferencesForReviewer,
    getTotalConferences
} = require("../controllers/dashboardController");

const router = express.Router();


const requireAuth = require('../middleware/requireAuth');
router.use(requireAuth);



router.get("/totalReviewers", getTotalReviewers);

router.get("/totalReviews", getTotalReviews);


router.get("/totalPapers", getTotalPapers);


router.get("/totalConferences", getTotalConferences);

router.get("/totalConferencesForReviewer", getConferencesForReviewer);

module.exports = router;
