const express = require("express");


const { insertReviewer, getReviewersByConferenceId } = require("../controllers/reviewerController");

const router = express.Router();

const requireAuth = require('../middleware/requireAuth');
router.use(requireAuth);


router.post("/insertReviewer", insertReviewer);

router.get("/:id", getReviewersByConferenceId);



module.exports = router