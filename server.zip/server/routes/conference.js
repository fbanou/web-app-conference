const express = require("express");


const {insertConference, getConference, getConferencesByAuthor, getConferenceById, getConferencesByReviewer} = require("../controllers/conferenceController");

const router = express.Router();

const requireAuth = require('../middleware/requireAuth');
router.use(requireAuth);


router.post("/insertConf", insertConference);


router.post("/getConf", getConference);

router.get("/:id", getConferencesByAuthor);

router.get("/reviewer/:id", getConferencesByReviewer);

router.get("/id/:id", getConferenceById);


module.exports = router