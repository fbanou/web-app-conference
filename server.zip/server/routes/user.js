const express = require("express");

const {loginUser, registerUser, token, allUsers, editUser, getUserByUsername} = require("../controllers/userController");

const router = express.Router();

router.post("/login", loginUser)


router.post("/register", registerUser)

router.get("/token", token)

router.put("/edit", editUser)

router.get("/getUserByUsername/:id", getUserByUsername)

router.get("/allUsers", allUsers)


module.exports = router