const express = require("express");


const {insertPost, getPostsbyPaperId, getPostsbyUser} = require("../controllers/postController");

const router = express.Router();

const requireAuth = require('../middleware/requireAuth');
router.use(requireAuth);


router.post("/insertPost", insertPost)


router.post("/getPosts", getPostsbyPaperId)


router.post("/getPostsbyUser", getPostsbyUser)

module.exports = router