import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { Box } from '@mui/material';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { useAuthContext } from "../../hooks/useAuthContext";
import { useRecommendation } from "../../hooks/useRecommendation";
import * as XLSX from 'xlsx';
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import { tokens } from "../../theme";

const Recommendation = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { recommendation, startRecommendation, recommendationReviewer } = useRecommendation();
  const { id } = useParams();
  const { user } = useAuthContext();
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = useCallback(async () => {
    if (!user || !user.token) return;

    try {
      setIsLoading(true);
      if (user.user[0].role === "admin") {
        await startRecommendation(id, user.token);
        const newData = await recommendation(id, user.token);
        setData(newData[0] || []);
      }
      else if (user.user[0].role === "reviewer") {
        //await startRecommendation(id , user.token);
        const newData = await recommendationReviewer(user.user[0].email, id, user.token);
        setData(newData[0] || []);
      }
    } catch (error) {
      console.error("Error fetching recommendation data:", error);
    } finally {
      setIsLoading(false);
    }
  }, [id, user, recommendation, startRecommendation, recommendationReviewer]);

  useEffect(() => {
    fetchData();
  }, []);

  const generateCSVContent = () => {
    const header = ['Name', 'Email', 'Assignment 1', 'Assignment 2', 'Assignment 3'].join(',');
    const csvRows = data.map(item => {
      const values = [
        item?.name,
        item?.email,
        item.assignment1,
        item.assignment2,
        item.assignment3
      ];
      return values.join(',');
    });
    return [header, ...csvRows].join('\n');
  };

    // Function to trigger download
  const downloadCSV = () => {
    const csvContent = generateCSVContent();
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'data.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadExcel = () => {
    const dataWithoutConferenceId = data.map(({ conferenceId, ...rest }) => rest);
    const reversedData = dataWithoutConferenceId.map(obj => {
      const keys = Object.keys(obj);
      const reorderedKeys = keys.slice(-2).concat(keys.slice(0, -2));
      const reorderedObj = {};
      reorderedKeys.forEach(key => {
        reorderedObj[key] = obj[key];
      });
      return reorderedObj;
    });

    const worksheet = XLSX.utils.json_to_sheet(reversedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Assignments');
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'assignments.xlsx');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const rows = data.map((item, index) => ({
    id: user.user[0].role === "reviewer" ? item.conferenceId : index  + 1,
    name: item?.name,
    email: item?.email,
    assignment1: item?.assignment1? item.assignment1 : '-',
    assignment2: item?.assignment2? item.assignment2 : '-',
    assignment3: item?.assignment3 ? item.assignment3 : '-',
  }));

  const columns = [
    ...(user.user[0].role === "reviewer" ? [{ field: 'id', headerName: 'Conference', flex: 1 }] : []),
    ...(user.user[0].role === "admin" ? [{ field: 'name', headerName: 'Name', flex: 1 }, { field: 'email', headerName: 'Email', flex: 1 }] : []),
    { field: 'assignment1', headerName: 'Assignment 1', flex: 1 },
    { field: 'assignment2', headerName: 'Assignment 2', flex: 1 },
    { field: 'assignment3', headerName: 'Assignment 3', flex: 1 },
  ];

  return (
    <Box m="20px">
      <Header title="Reviewer Assignments" subtitle="List of Assignments for Each Reviewer" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <DataGrid
            rows={rows}
            columns={columns}
            components={{ Toolbar: GridToolbar }}
          />
        )}
      </Box>
      <Box mt="20px" display="flex" justifyContent="flex-end">
        <button
          style={{
            padding: "10px 20px",
            backgroundColor: "#4caf50",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
          onClick={downloadExcel}
        >
          Export to Excel
        </button>
        <button
          style={{
            padding: "10px 20px",
            backgroundColor: "#4caf50",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
          onClick={downloadCSV}
        >
          Export to CSV
        </button>
      </Box>
    </Box>
  );
};

export default Recommendation;
