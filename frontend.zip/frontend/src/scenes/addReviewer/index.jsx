import React, { useState, useEffect, useCallback } from "react";
import {
  Box,
  Button,
  TextField,
  FormControl,
  Select,
  MenuItem,
  InputLabel,
  Snackbar,
  Alert,
} from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useConference } from "../../hooks/useConference";
import { useReviewer } from "../../hooks/useReviewer";
import Header from "../../components/Header";

const AddReviewer = () => {
  const { user } = useAuthContext();
  const { getConfByAuthor } = useConference();
  const { insertReviewer } = useReviewer();
  const [conferences, setConferences] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("success");

  // Fetch available conferences
  const fetchConferences = useCallback(async () => {
    if (!user || !user.user || !user.token) return;

    try {
      const data = await getConfByAuthor(user.user[0].username, user.token);
      setConferences(data || []);
    } catch (error) {
      console.error("Failed to fetch conferences:", error);
    }
  }, [user, getConfByAuthor]);

  useEffect(() => {
    fetchConferences();
  }, []);

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  return (
    <Box m="20px">
      <Header title="ADD A REVIEWER" subtitle="Add a reviewer in a conference" />

      <Formik
        initialValues={{
          conferenceId: "",
          name: "",
          email: "",
        }}
        validationSchema={yup.object().shape({
          conferenceId: yup.string().required("Conference selection is required"),
          name: yup.string().required("Name is required"),
          email: yup.string().email("Invalid email").required("Email is required"),
        })}
        onSubmit={async (values, { resetForm }) => {
          try {
            const result = await insertReviewer(
              values.conferenceId,
              values.name,
              values.email,
              user?.token
            );

            if (result?.error) {
              setSnackbarMessage("This reviewer already exists in this conference.");
              setSnackbarSeverity("error");
              setSnackbarOpen(true);
              return;
            }

            setSnackbarMessage("Successfully added the reviewer!");
            setSnackbarSeverity("success");
            setSnackbarOpen(true);
            resetForm();
          } catch (error) {
            console.error("Error adding reviewer:", error);
            setSnackbarMessage("An error occurred while adding the reviewer.");
            setSnackbarSeverity("error");
            setSnackbarOpen(true);
          }
        }}
      >
        {({ values, errors, touched, handleBlur, handleChange, handleSubmit }) => (
          <form onSubmit={handleSubmit}>
            <Box display="grid" gap="20px" gridTemplateColumns="repeat(4, minmax(0, 1fr))" sx={{ "& > div": { gridColumn: "span 4" } }}>
              
              <FormControl fullWidth variant="filled">
                <InputLabel id="conference-label">Select Conference</InputLabel>
                <Select
                  labelId="conference-label"
                  name="conferenceId"
                  value={values.conferenceId}
                  onChange={handleChange}
                  error={!!touched.conferenceId && !!errors.conferenceId}
                >
                  <MenuItem value=""><em>None</em></MenuItem>
                  {conferences.map(conf => (
                    <MenuItem key={conf.conferenceId} value={conf.conferenceId}>
                      {conf.title}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <TextField
                fullWidth
                variant="filled"
                label="Name"
                name="name"
                value={values.name}
                onBlur={handleBlur}
                onChange={handleChange}
                error={!!touched.name && !!errors.name}
                helperText={touched.name && errors.name}
              />

              <TextField
                fullWidth
                variant="filled"
                label="Email"
                name="email"
                value={values.email}
                onBlur={handleBlur}
                onChange={handleChange}
                error={!!touched.email && !!errors.email}
                helperText={touched.email && errors.email}
              />
            </Box>

            <Box display="flex" justifyContent="flex-end" mt="20px">
              <Button type="submit" color="secondary" variant="contained" size="large">
                Add Reviewer
              </Button>
            </Box>
          </form>
        )}
      </Formik>

      <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose} anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
        <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: "100%" }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AddReviewer;