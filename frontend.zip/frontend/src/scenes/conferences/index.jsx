import React, { useState, useEffect, useCallback } from "react";
import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useConference } from "../../hooks/useConference";
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import dayjs from "dayjs"; 

const Conferences = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { user } = useAuthContext();
  const { getConfByAuthor, getConfByReviewer } = useConference();
  const [conferences, setConferences] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const handleNavigate = (conferenceId) => {
    navigate(`/recommendation/${conferenceId}`);
  };

  
  const fetchConferences = useCallback(async () => {
    if (!user || !user.user || !user.token) return;

    try {
      setIsLoading(true); 

      if (user.user[0].role === "admin") {
        const data = await getConfByAuthor(user.user[0].username, user.token);
        setConferences(data || []);
      }
      else if (user.user[0].role === "reviewer") {
        const data = await getConfByReviewer(user.user[0].email, user.token);
        setConferences(data || []);
      }
    } catch (error) {
      console.error("Failed to fetch conferences:", error);
    } finally {
      setIsLoading(false); 
    }
  }, [user, getConfByAuthor, getConfByReviewer]);

  useEffect(() => {
    fetchConferences();
  }, []);

  
  const rows = conferences.map((conf) => ({
    id: conf.conferenceId,
    title: conf.title,
    city: conf.city,
    acronym: conf.acronym,
    startDate: conf.firstday ? dayjs(conf.firstday).format("DD/MM/YYYY") : "N/A",
    endDate: conf.lastday ? dayjs(conf.lastday).format("DD/MM/YYYY") : "N/A",
  }));

  const columns = [
    { field: "id", headerName: "ID", flex: 0.5 },
    { field: "title", headerName: "Title", flex: 1 },
    { field: "city", headerName: "City", flex: 1 },
    { field: "acronym", headerName: "Acronym", flex: 1 },
    { field: "startDate", headerName: "Start Date", flex: 1 },
    { field: "endDate", headerName: "End Date", flex: 1 },
    {
      field: "recommendations",
      headerName: "Recommendations",
      flex: 1,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <Button
          variant="contained"
          color="primary"
          onClick={() => handleNavigate(params.id)}
        >
          See the results
        </Button>
      ),
    },
  ];

  return (
    <Box m="20px">
      <Header title="MY CONFERENCES" subtitle="List of Conferences" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <DataGrid
            rows={rows}
            columns={columns}
            components={{ Toolbar: GridToolbar }}
          />
        )}
      </Box>
    </Box>
  );
};

export default Conferences;
