import React, { useState } from "react";
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Grid,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Modal,
  TextField,
  IconButton,
  Snackbar,
  useTheme,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import CloseIcon from "@mui/icons-material/Close";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useUsers } from "../../hooks/useUsers";
import Header from "../../components/Header";
import { useNavigate } from "react-router-dom";
import { useLogout } from '../../hooks/useLogout';

const ProfilePage = () => {
  const theme = useTheme();
  const { user } = useAuthContext();
  const { editUser, isLoading, error } = useUsers();
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editedDetails, setEditedDetails] = useState({});
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const navigate = useNavigate();
  const { logout } = useLogout();

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 

  if (!user || !user.user || !Array.isArray(user.user) || user.user.length === 0) {
    return (
      <Typography color="error" variant="h6" textAlign="center" mt={4}>
        User details not available.
      </Typography>
    );
  }

  const userDetails = user.user[0];

  const handleEditClick = () => {
    setEditedDetails(userDetails);
    setIsEditOpen(true);
  };

  const handleClose = () => {
    setIsEditOpen(false);
    setSnackbarOpen(false); 
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedDetails({ ...editedDetails, [name]: value });
  };

  const handleSave = async () => {
    
    if (!editedDetails.email || !editedDetails.phone) {
      setSnackbarMessage('Please fill in all required fields.');
      setSnackbarOpen(true);
      return;
    }

    if (!emailRegex.test(editedDetails.email)) {
      setSnackbarMessage('Invalid email format.');
      setSnackbarOpen(true);
      return;
    }
     
     if (JSON.stringify(userDetails) === JSON.stringify(editedDetails)) {
      setSnackbarMessage('No changes detected.');
      setSnackbarOpen(true);
      setIsEditOpen(false); 
      return;
    }

    try {
      const updatedUser = await editUser({
        ...editedDetails,
        prevUsername: userDetails.username, 
      });

      setSnackbarMessage('Profile updated successfully. Please log in again.');
      setSnackbarOpen(true);
      user.user[0] = updatedUser; 
      logout();
      navigate("/login");
    } catch (err) {
      console.error("Error saving profile:", err);
      setSnackbarMessage('Failed to update profile.');
      setSnackbarOpen(true);
    }
  };

  return (
    <Box>
      <Box m="20px">
        <Header title="My Profile" subtitle="View and Edit your Profile Info" />

        <Grid container justifyContent="center" spacing={4}>
          <Grid item xs={12} sm={10} md={6}>
            <Card
              sx={{
                maxWidth: 400,
                margin: "auto",
                boxShadow: 3,
                backgroundColor: theme.palette.background.paper,
              }}
            >
              <CardMedia
                component="img"
                image="https://static.thenounproject.com/png/5034901-200.png"
                alt="User Avatar"
                sx={{
                  height: 300,
                  width: 300,
                  objectFit: "cover",
                  margin: "auto",
                }}
              />
              <CardContent>
                <Typography
                  variant="body1"
                  textAlign="center"
                  color="secondary"
                  sx={{ fontFamily: theme.typography.subtitle1.fontFamily }}
                >
                  {userDetails.username}
                </Typography>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={10} md={6}>
            <Box>
              <Typography
                variant="h2"
                color="white"
                gutterBottom
                sx={{ fontFamily: theme.typography.subtitle1.fontFamily }}
              >
                Profile Details
              </Typography>

              <Accordion defaultExpanded>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography
                    color="secondary"
                    variant="h5"
                    sx={{ fontFamily: theme.typography.subtitle1.fontFamily }}
                  >
                    Personal Information
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>First Name: {userDetails.firstName || "N/A"}</Typography>
                  <Typography>Last Name: {userDetails.lastName || "N/A"}</Typography>
                </AccordionDetails>
              </Accordion>

              <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography
                    color="secondary"
                    variant="h5"
                    sx={{ fontFamily: theme.typography.subtitle1.fontFamily }}
                  >
                    Contact Details
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>Email: {userDetails.email || "N/A"}</Typography>
                  <Typography>Phone: {userDetails.phone || "N/A"}</Typography>
                </AccordionDetails>
              </Accordion>

              <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography
                    color="secondary"
                    variant="h5"
                    sx={{ fontFamily: theme.typography.subtitle1.fontFamily }}
                  >
                    Role Information
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>Role: {userDetails.role || "N/A"}</Typography>
                </AccordionDetails>
              </Accordion>
            </Box>
          </Grid>
        </Grid>

        <Box mt={4} textAlign="center">
          <Button
            variant="contained"
            color="secondary"
            sx={{
              padding: "10px 20px",
              fontSize: "16px",
            }}
            onClick={handleEditClick}
            disabled={isLoading}
          >
            Edit Profile
          </Button>
        </Box>
      </Box>

      <Modal open={isEditOpen} onClose={handleClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 400,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
            borderRadius: 2,
          }}
        >
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Edit Profile</Typography>
            <IconButton onClick={handleClose}>
              <CloseIcon />
            </IconButton>
          </Box>
          <TextField
            fullWidth
            label="Email"
            name="email"
            value={editedDetails.email || ""}
            onChange={handleInputChange}
            margin="normal"
          />
          <TextField
            fullWidth
            label="Phone"
            name="phone"
            value={editedDetails.phone || ""}
            onChange={handleInputChange}
            margin="normal"
          />
          <Box mt={2} textAlign="right">
            <Button
              variant="contained"
              color="primary"
              onClick={handleSave}
              sx={{ marginRight: 1 }}
              disabled={isLoading}
            >
              Save
            </Button>
            <Button variant="outlined" onClick={handleClose}>
              Cancel
            </Button>
          </Box>
          {error && (
            <Typography color="error" variant="body2" mt={2}>
              {error}
            </Typography>
          )}
        </Box>
      </Modal>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
        message={snackbarMessage}
      />
    </Box>
  );
};

export default ProfilePage;
