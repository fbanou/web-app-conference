import React, { useEffect, useState, useCallback } from "react";
import { Box, Typography, CircularProgress, useTheme } from "@mui/material";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import PieChart from "../../components/PieChart";
import BarChart from "../../components/BarChart";
import StatBox from "../../components/StatBox";
import StickyNote2OutlinedIcon from "@mui/icons-material/StickyNote2Outlined";
import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import BadgeOutlinedIcon from "@mui/icons-material/BadgeOutlined";
import { useDashboard } from "../../hooks/useDashboard";
import { useAuthContext } from "../../hooks/useAuthContext";

const Dashboard = () => {
    const theme = useTheme();
    const { user } = useAuthContext();
    const colors = tokens(theme.palette.mode);


    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [totalReviewers, setTotalReviewers] = useState(0);
    const [totalPapers, setTotalPapers] = useState(0);
    const [totalConferences, setTotalConferences] = useState(0);

    const { getTotalReviewers, getTotalPapers, getTotalConferences, getTotalReviews, getConferencesForReviewer } = useDashboard();

  
    const fetchData = useCallback(async () => {
        try {
            setIsLoading(true);
            setError(null);

            if (user.user[0].role === "admin") {
                const [reviewers, papers, conferences] = await Promise.all([
                    getTotalReviewers(user.token),
                    getTotalPapers(user.token),
                    getTotalConferences(user.token),
                ]);
                setTotalReviewers(reviewers);
                setTotalPapers(papers);
                setTotalConferences(conferences);
            }
            else if (user.user[0].role === "reviewer") {
                const [reviews, conferences] = await Promise.all([
                    getTotalReviews(user.token),
                    getConferencesForReviewer(user.token),
                ]);
    
                setTotalReviewers(reviews);
                setTotalConferences(conferences);
                setTotalPapers(0);
            }
            
        } catch (err) {
            console.error("Failed to fetch dashboard data:", err);
            setError("Failed to load data. Please try again.");
        } finally {
            setIsLoading(false);
        }
    }, [getTotalReviewers, getTotalPapers, getTotalConferences, getTotalReviews, getConferencesForReviewer, user.token]);

    useEffect(() => {
        fetchData();
    }, []); 

 
    if (isLoading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
                <CircularProgress />
            </Box>
        );
    }

 
    if (error) {
        return (
            <Box m="20px">
                <Header title="DASHBOARD" subtitle="Error Loading Data" />
                <Typography color="error">{error}</Typography>
            </Box>
        );
    }


    if (user.user[0].role === "admin") {
        return (
            <Box m="20px">
               
                <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Header title="ADMIN DASHBOARD" subtitle="Welcome to Conference's Management App" />
                </Box>

               
                <Box
                    display="grid"
                    gridTemplateColumns="repeat(12, 1fr)"
                    gridAutoRows="140px"
                    gap="20px"
                >
                    
                    <Box
                        gridColumn="span 4"
                        backgroundColor={colors.primary[400]}
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                    >
                        <StatBox
                            title={totalReviewers}
                            subtitle="Total Reviewers"
                            progress={totalReviewers/10}
                            icon={
                                <PeopleOutlinedIcon
                                    sx={{ color: colors.greenAccent[600], fontSize: "26px" }}
                                />
                            }
                        />
                    </Box>
                    <Box
                        gridColumn="span 4"
                        backgroundColor={colors.primary[400]}
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                    >
                        <StatBox
                            title={totalPapers}
                            subtitle="Total Papers"
                            progress={totalPapers/10}
                            icon={
                                <StickyNote2OutlinedIcon
                                    sx={{ color: colors.greenAccent[600], fontSize: "26px" }}
                                />
                            }
                        />
                    </Box>
                    <Box
                        gridColumn="span 4"
                        backgroundColor={colors.primary[400]}
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                    >
                        <StatBox
                            title={totalConferences}
                            subtitle="Total Conferences"
                            progress={totalConferences/10}
                            icon={
                                <BadgeOutlinedIcon
                                    sx={{ color: colors.greenAccent[600], fontSize: "26px" }}
                                />
                            }
                        />
                    </Box>

                   
                    <Box gridColumn="span 6" gridRow="span 2" backgroundColor={colors.primary[400]}>
                        <Typography
                            variant="h5"
                            fontWeight="600"
                            sx={{ padding: "30px 30px 0 30px" }}
                        >
                            Bar Chart
                        </Typography>
                        <Box height="250px">
                            <BarChart isDashboard={true} />
                        </Box>
                    </Box>
                    <Box
                        gridColumn="span 6"
                        gridRow="span 2"
                        backgroundColor={colors.primary[400]}
                        padding="30px"
                    >
                        <Typography
                            variant="h5"
                            fontWeight="600"
                            sx={{ marginBottom: "15px" }}
                        >
                            Pie Chart
                        </Typography>
                        <Box height="200px">
                            <PieChart isDashboard={true} />
                        </Box>
                    </Box>
                </Box>
            </Box>
        );
    }

    if (user.user[0].role === "reviewer") {
        return (
            <Box m="20px">
           
              <Box display="flex" justifyContent="space-between" alignItems="center">
                <Header
                  title="REVIEWER DASHBOARD"
                  subtitle="Welcome to Conference's Management App"
                />
              </Box>
        
            
              <Box
                display="grid"
                gridTemplateColumns="repeat(12, 1fr)"
                gridAutoRows="140px"
                gap="20px"
              >
             
                <Box
                  gridColumn="span 6"
                  backgroundColor={colors.primary[400]}
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <StatBox
                    title={totalReviewers}
                    subtitle="Total Reviews"
                    progress={totalReviewers/10}
                    icon={
                      <PeopleOutlinedIcon
                        sx={{ color: colors.greenAccent[600], fontSize: "26px" }}
                      />
                    }
                  />
                </Box>
                <Box
                  gridColumn="span 6"
                  backgroundColor={colors.primary[400]}
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <StatBox
                    title={totalConferences}
                    subtitle="Total Conferences"
                    progress={totalConferences/10}
                    icon={
                      <BadgeOutlinedIcon
                        sx={{ color: colors.greenAccent[600], fontSize: "26px" }}
                      />
                    }
                  />
                </Box>
        
              
                <Box
                  gridColumn="span 12"
                  gridRow="span 2"
                  backgroundColor={colors.primary[400]}
                >
                  <Typography
                    variant="h5"
                    fontWeight="600"
                    sx={{ padding: "20px 30px 0 30px" }}
                  >
                    Bar Chart
                  </Typography>
                  <Box height="250px">
                    <BarChart isDashboard={true} />
                  </Box>
                </Box>
              </Box>
            </Box>
          );
    }
};

export default Dashboard;
