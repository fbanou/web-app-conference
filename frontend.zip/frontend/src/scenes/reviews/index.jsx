import React, { useState, useEffect, useCallback } from "react";
import { Box, useTheme } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import { useAuthContext } from "../../hooks/useAuthContext";
import { usePost } from "../../hooks/usePost";
import Header from "../../components/Header";
import { useParams } from 'react-router-dom';

const Reviews = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [isLoading, setIsLoading] = useState(true);
  const { getPostsbyUser, getUserByPaper } = usePost();
  const { user } = useAuthContext();
  const [posts, setPosts] = useState([]);
  const { id } = useParams();

  const fetchPosts = useCallback(async () => {
    if (!user || !user.user || !user.token) return;

    try {
      setIsLoading(true); 
      if (user.user[0].role === "admin") {
        const Posts = await getUserByPaper(id, user.token);
        setPosts(Posts || []);
      }
      else if (user.user[0].role === "reviewer") {
        const Posts = await getPostsbyUser(user.user[0].userId, user.token);
        setPosts(Posts || []);
      }
    } catch (error) {
      console.error("Failed to fetch conferences:", error);
    } finally {
      setIsLoading(false); 
    }
  }, [getPostsbyUser, user.token]);

  useEffect(() => {
    fetchPosts();
  }, []);

  const columns = [
    ...(user.user[0].role === "reviewer" ? [{ field: "paper", headerName: "Paper ID", flex: 0.5 }, { field: "conference", headerName: "Conference", flex: 1 },] : []),
    ...(user.user[0].role === "admin" ? [{ field: "id", headerName: "ID", flex: 0.5 },{ field: 'reviewer', headerName: 'Reviewer', flex: 1 }] : []),
    { field: "post", headerName: "Review Content", flex: 2 },
  ];

  const rows = posts.map((post) => ({
    id: post.postId,
    post: post.post,
    paper: post.paperId,
    conference: post.conference,
    reviewer: post.username
  }));

  return (
    <Box m="20px">
      <Header title="MY REVIEWS" subtitle="View Your Reviews on Papers" />

      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <DataGrid
            rows={rows}
            columns={columns}
            components={{ Toolbar: GridToolbar }}
          />
        )}
      </Box>
    </Box>
  );
};

export default Reviews;
