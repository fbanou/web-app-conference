import { Box, useTheme } from "@mui/material";
import Header from "../../components/Header";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { tokens } from "../../theme";

const FAQ = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <Box m="20px">
      <Header title="Basic informations about the project" subtitle="Web based reccomendation system for scientific conferences" />

      <Accordion defaultExpanded>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography color={colors.greenAccent[500]} variant="h5">
           ADMINISTRATOR
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          This website is a comprehensive management platform for conference organizers and reviewers. Administrators can efficiently manage reviewers and access detailed information about them. Users can create new conferences and view a complete list of all their events. They can also add and manage papers for each conference, with the platform providing recommendations on which reviewer is best suited for each paper. Additionally, users can update their profiles with options to view and edit personal information. The site features an interactive calendar for  event scheduling. It also offers insightful data visualizations, including diagrams and percentage charts, to track conference progress. A user-friendly interface supports both dark and light modes, ensuring a personalized experience.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion defaultExpanded>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography color={colors.greenAccent[500]} variant="h5">
            REVIEWER
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          Reviewers can join conferences and access a list of all conferences they have joined, along with a complete list of papers associated with those conferences. They can submit reviews for their assigned papers through a dedicated form. A review history feature enables reviewers to track their past submissions. The platform also includes a profile section for viewing and editing personal information. An integrated calendar helps reviewers efficiently organize their schedules. With a user-friendly interface supporting both dark and light modes, the platform ensures a personalized and seamless experience.
          </Typography>
        </AccordionDetails>
      </Accordion>
    </Box>
  );
};

export default FAQ;
