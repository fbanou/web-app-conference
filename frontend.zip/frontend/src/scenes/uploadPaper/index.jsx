import React, { useState, useEffect, useCallback } from "react";
import {
  Box,
  Button,
  FormControl,
  Select,
  MenuItem,
  InputLabel,
  Snackbar,
  Alert,
  Typography,
} from "@mui/material";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useConference } from "../../hooks/useConference";
import { usePaper } from "../../hooks/usePaper";
import Header from "../../components/Header";
import * as XLSX from "xlsx";
import * as Papa from "papaparse";

const FileSelector = ({ onChange }) => {
  const handleFileChange = async (e) => {
    if (e.target.files.length === 0) return;

    const file = e.target.files[0];
    const fileType = file.name.split(".").pop().toLowerCase();
    const fileUrl = URL.createObjectURL(file);

    try {
      if (fileType === "csv") {
        // Parse CSV file
        const response = await fetch(fileUrl);
        const text = await response.text();
        const { data } = Papa.parse(text, { header: true });
        onChange(data);
      } else if (fileType === "xlsx" || fileType === "xls") {
        // Parse Excel file
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const parsedData = XLSX.utils.sheet_to_json(worksheet);
        onChange(parsedData);
      } else {
        alert("Unsupported file format! Please upload CSV or Excel files.");
      }
    } catch (error) {
      console.error("Error processing file:", error);
    }
  };

  return <input type="file" accept=".csv, .xlsx, .xls" onChange={handleFileChange} />;
};

const UploadPaper = () => {
  const { user } = useAuthContext();
  const { getConfByAuthor } = useConference();
  const { insertPaper } = usePaper();

  const [conferences, setConferences] = useState([]);
  const [selectedConference, setSelectedConference] = useState("");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("success");
  const [csvData, setCsvData] = useState([]);

  // Fetch conferences for the logged-in author
  const fetchConferences = useCallback(async () => {
    if (!user || !user.user || !user.token) return;

    try {
      const data = await getConfByAuthor(user.user[0].username, user.token);
      setConferences(data || []);
    } catch (error) {
      console.error("Failed to fetch conferences:", error);
    }
  }, [user, getConfByAuthor]);

  useEffect(() => {
    fetchConferences();
  }, []);

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  const handleUpload = async () => {
    if (!selectedConference) {
      setSnackbarMessage("Please select a conference before uploading.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return;
    }

    if (csvData.length === 0) {
      setSnackbarMessage("No valid data found in the file.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return;
    }

    try {
      const results = await Promise.allSettled(
        csvData.map((row) => insertPaper(selectedConference, row.title, row.abstract, user.token))
      );

      const failedUploads = results.filter((result) => result.status === "fulfilled" && result.value?.error);

      if (failedUploads.length > 0) {
        setSnackbarMessage("Papers with this title already exists.");
        setSnackbarSeverity("error");
      } else {
        setSnackbarMessage("Successfully uploaded all papers!");
        setSnackbarSeverity("success");
      }
      setSnackbarOpen(true);
    } catch (error) {
      console.error("Error uploading papers:", error);
      setSnackbarMessage("An error occurred while uploading the papers.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
    }
  };

  return (
    <Box m="20px">
      <Header title="UPLOAD A PAPER" subtitle="Upload Papers to a Conference via CSV or Excel" />

      <Box mt={4}>
        <FormControl fullWidth variant="filled" sx={{ mb: 2 }}>
          <InputLabel id="conference-label">Select Conference</InputLabel>
          <Select
            labelId="conference-label"
            value={selectedConference}
            onChange={(e) => setSelectedConference(e.target.value)}
          >
            {conferences.map((conf) => (
              <MenuItem key={conf.conferenceId} value={conf.conferenceId}>
                {conf.title}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <FileSelector onChange={setCsvData} />

        {csvData.length > 0 && (
          <Box mt={3}>
            <Typography variant="subtitle1">Preview of Uploaded Data:</Typography>
            <table className="table">
              <thead>
                <tr className="table-info">
                  {Object.keys(csvData[0]).map((key) => (
                    <th key={key}>{key}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {csvData.map((row, index) => (
                  <tr key={index}>
                    <td>{row.title}</td>
                    <td>
                      {row.abstract.length > 40
                        ? row.abstract.substring(0, 40) + "..."
                        : row.abstract}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Box>
        )}

        <Box display="flex" justifyContent="flex-end" mt="20px">
          <Button
            type="submit"
            color="secondary"
            variant="contained"
            onClick={handleUpload}
          >
            Upload Papers
          </Button>
        </Box>
      </Box>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: "100%" }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default UploadPaper;
