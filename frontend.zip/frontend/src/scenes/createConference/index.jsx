import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Snackbar,
  Alert,
} from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
//import { useNavigate } from "react-router-dom";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useConference } from "../../hooks/useConference";
import Header from "../../components/Header";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

const CreateConference = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  
  const { user } = useAuthContext();
  const { insertConference } = useConference();

 
  const [snackbarOpen, setSnackbarOpen] = useState(false);

  
  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  const handleFormSubmit = async (values, { resetForm }) => {
    try {
      await insertConference(
        values.userId,
        values.author,
        values.title,
        values.acronym,
        values.webpage,
        values.city,
        values.country,
        values.firstday,
        values.lastday,
        values.primaryarea,
        values.secondaryarea,
        values.organizer,
        user.token
      );

      console.log("Conference created successfully", values);

      resetForm(); 

      
      setSnackbarOpen(true);
    } catch (error) {
      console.error("Error creating conference:", error);
      
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box m="20px">
        <Header title="CREATE CONFERENCE" subtitle="Create a New Conference" />

        <Formik
          onSubmit={handleFormSubmit}
          initialValues={{
            userId: user?.user[0]?.userId || "",
            author: user?.user[0]?.username || "",
            title: "",
            acronym: "",
            webpage: "",
            city: "",
            country: "",
            firstday: "",
            lastday: "",
            primaryarea: "",
            secondaryarea: "",
            organizer: "",
          }}
          validationSchema={validationSchema}
        >
          {({
            values,
            errors,
            touched,
            setFieldValue,
            handleBlur,
            handleChange,
            handleSubmit,
          }) => (
            <form onSubmit={handleSubmit}>
              <Box
                display="grid"
                gap="30px"
                gridTemplateColumns="repeat(4, minmax(0, 1fr))"
                sx={{
                  "& > div": { gridColumn: isNonMobile ? undefined : "span 4" },
                }}
              >
                <TextField
                  fullWidth
                  variant="filled"
                  type="text"
                  label="Conference Title"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.title}
                  name="title"
                  error={!!touched.title && !!errors.title}
                  helperText={touched.title && errors.title}
                  sx={{ gridColumn: "span 4" }}
                />
                <TextField
                  fullWidth
                  variant="filled"
                  type="text"
                  label="Acronym"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.acronym}
                  name="acronym"
                  error={!!touched.acronym && !!errors.acronym}
                  helperText={touched.acronym && errors.acronym}
                  sx={{ gridColumn: "span 4" }}
                />
                <TextField
                  fullWidth
                  variant="filled"
                  type="text"
                  label="Webpage"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.webpage}
                  name="webpage"
                  error={!!touched.webpage && !!errors.webpage}
                  helperText={touched.webpage && errors.webpage}
                  sx={{ gridColumn: "span 4" }}
                />
                <TextField
                  fullWidth
                  variant="filled"
                  type="text"
                  label="City"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.city}
                  name="city"
                  error={!!touched.city && !!errors.city}
                  helperText={touched.city && errors.city}
                  sx={{ gridColumn: "span 2" }}
                />
                <TextField
                  fullWidth
                  variant="filled"
                  type="text"
                  label="Country"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.country}
                  name="country"
                  error={!!touched.country && !!errors.country}
                  helperText={touched.country && errors.country}
                  sx={{ gridColumn: "span 2" }}
                />
               
                <FormControl sx={{ gridColumn: "span 2" }}>
                  <DatePicker
                    label="First Day"
                    value={values.firstday ? dayjs(values.firstday) : null}
                    onChange={(newValue) => {
                      const formattedDate = newValue ? dayjs(newValue).format("YYYY-MM-DD") : "";
                      
                      
                      if (newValue && dayjs(newValue).isBefore(dayjs(), 'day')) {
                        alert("The selected date has already passed!");
                      }
                      
                      setFieldValue("firstday", formattedDate);
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="filled"
                        error={!!touched.firstday && !!errors.firstday}
                        helperText={touched.firstday && errors.firstday}
                      />
                    )}
                  />
                </FormControl>
               
                <FormControl sx={{ gridColumn: "span 2" }}>
                  <DatePicker
                    label="Last Day"
                    value={values.lastday ? dayjs(values.lastday) : null}
                    onChange={(newValue) => {
                      const formattedDate = newValue ? dayjs(newValue).format("YYYY-MM-DD") : "";

                      
                      if (newValue && dayjs(newValue).isBefore(dayjs(), 'day')) {
                        alert("The selected end date has already passed!");
                      }

                      
                      if (newValue && dayjs(newValue).isBefore(dayjs(values.firstday), 'day')) {
                        alert("The end date cannot be before the start date!");
                      }

                      setFieldValue("lastday", formattedDate);
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="filled"
                        error={!!touched.lastday && !!errors.lastday}
                        helperText={touched.lastday && errors.lastday}
                      />
                    )}
                  />
                </FormControl>
                <FormControl
                  fullWidth
                  variant="filled"
                  sx={{ gridColumn: "span 2" }}
                >
                  <InputLabel id="primary-area-label">Primary Area</InputLabel>
                  <Select
                    labelId="primary-area-label"
                    value={values.primaryarea}
                    name="primaryarea"
                    onChange={handleChange}
                    error={!!touched.primaryarea && !!errors.primaryarea}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value="6">Accounting and Finance</MenuItem>
                    <MenuItem value="8">Art and Humanities</MenuItem>
                    <MenuItem value="11">Biological Sciences</MenuItem>
                    <MenuItem value="5">Business and Management</MenuItem>
                    <MenuItem value="3">Chemistry</MenuItem>
                    <MenuItem value="23">Civil Engineering</MenuItem>
                    <MenuItem value="1">Computing</MenuItem>
                    <MenuItem value="12">
                      Earth and Environmental Sciences
                    </MenuItem>
                    <MenuItem value="15">Economics</MenuItem>
                    <MenuItem value="16">Education Science</MenuItem>
                    <MenuItem value="17">Energy</MenuItem>
                    <MenuItem value="2">Engineering</MenuItem>
                    <MenuItem value="13">Genomics and Bioinformatics</MenuItem>
                    <MenuItem value="10">Health Sciences</MenuItem>
                    <MenuItem value="7">Language and Linguistics</MenuItem>
                    <MenuItem value="14">Materials Science</MenuItem>
                    <MenuItem value="19">Mathematics and Statistics</MenuItem>
                    <MenuItem value="24">Mechanical Engineering</MenuItem>
                    <MenuItem value="4">Physics</MenuItem>
                    <MenuItem value="9">Social Sciences</MenuItem>
                    <MenuItem value="18">Technology</MenuItem>
                  </Select>
                </FormControl>
                
                <FormControl
                  fullWidth
                  variant="filled"
                  sx={{ gridColumn: "span 2" }}
                >
                  <InputLabel id="secondary-area-label">
                    Secondary Area
                  </InputLabel>
                  <Select
                    labelId="secondary-area-label"
                    value={values.secondaryarea}
                    name="secondaryarea"
                    onChange={handleChange}
                    error={!!touched.secondaryarea && !!errors.secondaryarea}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    <MenuItem value="6">Accounting and Finance</MenuItem>
                    <MenuItem value="8">Art and Humanities</MenuItem>
                    <MenuItem value="11">Biological Sciences</MenuItem>
                    <MenuItem value="5">Business and Management</MenuItem>
                    <MenuItem value="3">Chemistry</MenuItem>
                    <MenuItem value="23">Civil Engineering</MenuItem>
                    <MenuItem value="1">Computing</MenuItem>
                    <MenuItem value="12">
                      Earth and Environmental Sciences
                    </MenuItem>
                    <MenuItem value="15">Economics</MenuItem>
                    <MenuItem value="16">Education Science</MenuItem>
                    <MenuItem value="17">Energy</MenuItem>
                    <MenuItem value="2">Engineering</MenuItem>
                    <MenuItem value="13">Genomics and Bioinformatics</MenuItem>
                    <MenuItem value="10">Health Sciences</MenuItem>
                    <MenuItem value="7">Language and Linguistics</MenuItem>
                    <MenuItem value="14">Materials Science</MenuItem>
                    <MenuItem value="19">Mathematics and Statistics</MenuItem>
                    <MenuItem value="24">Mechanical Engineering</MenuItem>
                    <MenuItem value="4">Physics</MenuItem>
                    <MenuItem value="9">Social Sciences</MenuItem>
                    <MenuItem value="18">Technology</MenuItem>
                  </Select>
                </FormControl>
                <TextField
                  fullWidth
                  variant="filled"
                  type="text"
                  label="Organizer"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.organizer}
                  name="organizer"
                  error={!!touched.organizer && !!errors.organizer}
                  helperText={touched.organizer && errors.organizer}
                  sx={{ gridColumn: "span 4" }}
                />
              </Box>
              <Box display="flex" justifyContent="end" mt="20px">
                <Button type="submit" color="secondary" variant="contained">
                  CREATE
                </Button>
              </Box>
            </form>
          )}
        </Formik>

      
        <Snackbar
          open={snackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
        >
          <Alert
            onClose={handleSnackbarClose}
            severity="success"
            sx={{ width: "100%" }}
          >
            Conference Created Successfully!
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
};

const validationSchema = yup.object().shape({
  title: yup.string().required("Title is required"),
  acronym: yup.string().required("Acronym is required"),
  city: yup.string().required("City is required"),
  country: yup.string().required("Country is required"),
  firstday: yup.date().required("First day is required"),
  lastday: yup.date().required("Last day is required"),
  organizer: yup.string().required("Organizer is required"),
});

export default CreateConference;
