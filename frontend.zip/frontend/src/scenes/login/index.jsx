import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useLogin } from "../../hooks/useLogin";
import { Box, IconButton, useTheme, Alert } from "@mui/material";
import { ColorModeContext } from "../../theme";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";

export default function Login() {
  const theme = useTheme();
  const colorMode = useContext(ColorModeContext);

  const [logUser, setLogUser] = useState({
    username: "",
    password: "",
  });
  const [alert, setAlert] = useState(null); 
  const { login } = useLogin();
  const navigate = useNavigate();

  function handleChangeLogin(event) {
    const { name, value } = event.target;

    setLogUser((prevValue) => ({
      ...prevValue,
      [name]: value,
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const userData = await login(logUser.username, logUser.password);

      if (userData?.error) {
        setAlert("Invalid username or password"); 
        console.log("Login failed:", userData.error);
      } else {
        console.log("Login successful:", userData);

        const userRole = userData?.user[0].role;
        console.log("role:", userRole);

        navigate("/dashboard");
      }
    } catch (err) {
      setAlert("An error occurred. Please try again."); 
      console.error("An error occurred during login:", err);
    }
  }

  return (
    <div
      className="login-page"
      style={{
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: theme.palette.mode === "dark" ? "#121212" : "#f9f9f9",
      }}
    >
      <Box
        position="absolute"
        top="20px"
        right="20px"
        zIndex={1}
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <IconButton
          onClick={colorMode.toggleColorMode}
          style={{
            backgroundColor: theme.palette.mode === "dark" ? "#333" : "#f5f5f5",
            color: theme.palette.mode === "dark" ? "#fff" : "#333",
            boxShadow: "0 2px 5px rgba(0, 0, 0, 0.2)",
            borderRadius: "50%",
          }}
        >
          {theme.palette.mode === "dark" ? (
            <LightModeOutlinedIcon />
          ) : (
            <DarkModeOutlinedIcon />
          )}
        </IconButton>
      </Box>
      <div
        className="login-card"
        style={{
          width: "400px",
          padding: "30px",
          borderRadius: "10px",
          backgroundColor: theme.palette.mode === "dark" ? "#333" : "#ffffff",
          boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
          textAlign: "center",
          color: theme.palette.mode === "dark" ? "#fff" : "#333",
        }}
      >
        <div className="login-header" style={{ marginBottom: "20px" }}>
          <h1 style={{ fontSize: "2em", marginBottom: "10px" }}>Login</h1>
          <p style={{ fontSize: "1em" }}>
            Welcome back! Please log in to your account.
          </p>
        </div>

        {/* Show Alert if an error occurs */}
        {alert && (
          <Alert
            variant="outlined"
            severity="error"
            onClose={() => setAlert(null)} 
            style={{ marginBottom: "15px" }}
          >
            {alert}
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group" style={{ marginBottom: "15px" }}>
            <input
              onChange={handleChangeLogin}
              name="username"
              placeholder="Username"
              value={logUser.username}
              required
              className="form-control"
              style={{
                width: "100%",
                padding: "10px",
                border: "none",
                borderBottom: "2px solid transparent",
                borderImageSource: "linear-gradient(to right, #1e90ff, #ff00ff)",
                borderImageSlice: 1,
                outline: "none",
                fontSize: "1em",
                backgroundColor: "transparent",
                color: theme.palette.mode === "dark" ? "#fff" : "#333",
                transition: "border-image-source 0.3s ease",
              }}
              onFocus={(e) =>
                (e.target.style.borderImageSource =
                  "linear-gradient(to right, #1e90ff, #ff00ff)")
              }
              onBlur={(e) =>
                (e.target.style.borderImageSource =
                  "linear-gradient(to right, #1e90ff, #ff00ff)")
              }
            />
          </div>
          <div className="form-group" style={{ marginBottom: "20px" }}>
            <input
              onChange={handleChangeLogin}
              name="password"
              placeholder="Password"
              value={logUser.password}
              required
              type="password"
              className="form-control"
              style={{
                width: "100%",
                padding: "10px",
                border: "none",
                borderBottom: "2px solid transparent",
                borderImageSource: "linear-gradient(to right, #1e90ff, #ff00ff)",
                borderImageSlice: 1,
                outline: "none",
                fontSize: "1em",
                backgroundColor: "transparent",
                color: theme.palette.mode === "dark" ? "#fff" : "#333",
                transition: "border-image-source 0.3s ease",
              }}
              onFocus={(e) =>
                (e.target.style.borderImageSource =
                  "linear-gradient(to right, #1e90ff, #ff00ff)")
              }
              onBlur={(e) =>
                (e.target.style.borderImageSource =
                  "linear-gradient(to right, #1e90ff, #ff00ff)")
              }
            />
          </div>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "25px",
              background: "linear-gradient(to right, #1e90ff, #ff00ff)",
              color: "#fff",
              border: "none",
              fontSize: "1em",
              cursor: "pointer",
            }}
          >
            LOG IN
          </button>
        </form>
        <div style={{ marginTop: "20px" }}>
          <p style={{ fontSize: "1em" }}>
            Don't have an account?{" "}
            <Link
              to="/register"
              style={{
                color: theme.palette.mode === "dark" ? "#90caf9" : "#007bff",
                textDecoration: "none",
              }}
            >
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
