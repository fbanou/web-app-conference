import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useRegister } from "../../hooks/useRegister";
import { IconButton, useTheme } from "@mui/material";
import { ColorModeContext, tokens } from "../../theme";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";

export default function Register() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const colorMode = useContext(ColorModeContext);

  const [regUser, setRegUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    username: "",
    password: "",
    role: "",
  });
  const { register, error, isLoading } = useRegister();
  const navigate = useNavigate();

  function handleChangeRegister(event) {
    const { name, value } = event.target;
    setRegUser((prevValue) => ({
      ...prevValue,
      [name]: value,
    }));
  }

  async function isAllValid(event) {
    if (
      regUser.firstName.length === 0 ||
      regUser.lastName.length === 0 ||
      regUser.username.length < 4
    ) {
      alert("Check the fields!");
      event.preventDefault();
    }

    if (!regUser.email.includes("@")) {
      alert("The email must include '@'");
      event.preventDefault();
    }

    if (regUser.password.length < 8) {
      alert("The password length must be at least 8 characters.");
      event.preventDefault();
    }

    if (!/\d/.test(regUser.password)) {
      alert("The password must contain at least one number.");
      event.preventDefault();
    }

    if (regUser.phone.length < 10) {
      alert("The phone number length must be at least 10 characters.");
      event.preventDefault();
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    await register(
      regUser.firstName,
      regUser.lastName,
      regUser.email,
      regUser.phone,
      regUser.username,
      regUser.password,
      regUser.role
    );

    console.log("phone:", regUser.phone);
    navigate("/dashboard");
  }

  return (
    <div
      className="register-page"
      style={{
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor:
          theme.palette.mode === "dark" ? "#121212" : "#f9f9f9",
      }}
    >
      {/* Theme Toggle Button */}
      <IconButton
        onClick={colorMode.toggleColorMode}
        style={{
          position: "absolute",
          top: "20px",
          right: "20px",
          backgroundColor: theme.palette.mode === "dark" ? "#333" : "#f5f5f5",
          color: theme.palette.mode === "dark" ? "#fff" : "#333",
          boxShadow: "0 2px 5px rgba(0, 0, 0, 0.2)",
        }}
      >
        {theme.palette.mode === "dark" ? (
          <LightModeOutlinedIcon />
        ) : (
          <DarkModeOutlinedIcon />
        )}
      </IconButton>

      <div
        className="register-card"
        style={{
          width: "400px",
          padding: "30px",
          borderRadius: "10px",
          backgroundColor:
            theme.palette.mode === "dark" ? "#333" : "#ffffff",
          boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
          textAlign: "center",
          color: theme.palette.mode === "dark" ? "#fff" : "#333",
        }}
      >
        <div className="register-header" style={{ marginBottom: "20px" }}>
          <h1 style={{ fontSize: "2em", marginBottom: "10px" }}>Create Account</h1>
          <p style={{ fontSize: "1em" }}>Sign up to start using our platform!</p>
        </div>
        <form onSubmit={handleSubmit}>
          {["firstName", "lastName", "email", "phone", "username", "password"].map(
            (field, index) => (
              <div key={index} className="form-group" style={{ marginBottom: "15px" }}>
                <input
                  onChange={handleChangeRegister}
                  name={field}
                  placeholder={
                    field.charAt(0).toUpperCase() + field.slice(1).replace("Name", " Name")
                  }
                  value={regUser[field]}
                  required
                  type={field === "password" ? "password" : "text"}
                  className="form-control"
                  style={{
                    width: "100%",
                    padding: "10px",
                    border: "none",
                    borderBottom: "2px solid transparent",
                    borderImageSource: "linear-gradient(to right, #1e90ff, #ff00ff)",
                    borderImageSlice: 1,
                    outline: "none",
                    fontSize: "1em",
                    backgroundColor: "transparent",
                    color: theme.palette.mode === "dark" ? "#fff" : "#333",
                    transition: "border-image-source 0.3s ease",
                  }}
                  onFocus={(e) =>
                    (e.target.style.borderImageSource =
                      "linear-gradient(to right, #1e90ff, #ff00ff)")
                  }
                  onBlur={(e) =>
                    (e.target.style.borderImageSource =
                      "linear-gradient(to right, #1e90ff, #ff00ff)")
                  }
                />
              </div>
            )
          )}
          <div className="form-group" style={{ marginBottom: "15px" }}>
            <select
              onChange={handleChangeRegister}
              name="role"
              value={regUser.role}
              required
              className="form-control"
              style={{
                width: "100%",
                padding: "10px",
                border: "none",
                borderBottom: "2px solid transparent",
                borderImageSource: "linear-gradient(to right, #1e90ff, #ff00ff)",
                borderImageSlice: 1,
                outline: "none",
                fontSize: "1em",
                backgroundColor: theme.palette.mode === "dark" ? "#444" : "#f9f9f9",
                color: theme.palette.mode === "dark" ? "#fff" : "#333",
                borderRadius: "5px",
                appearance: "none",
                backgroundRepeat: "no-repeat",
                backgroundPosition: "calc(100% - 10px) center",
                backgroundSize: "12px",
              }}
            >
              <option value="" disabled>
                Select Role
              </option>
              <option value="admin">Admin</option>
              <option value="reviewer">Reviewer</option>
            </select>
          </div>
          <button
            onClick={isAllValid}
            className="btn btn-primary"
            disabled={isLoading}
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "25px",
              background: "linear-gradient(to right, #1e90ff, #ff00ff)",
              color: "#fff",
              border: "none",
              fontSize: "1em",
              cursor: "pointer",
              marginBottom: "15px",
            }}
          >
            Register
          </button>
          {error && (
            <div style={{ color: "red", fontSize: "0.9em", marginBottom: "15px" }}>
              {error}
            </div>
          )}
        </form>
        <p style={{ fontSize: "1em" }}>
          Already have an account?{" "}
          <Link
            to="/login"
            style={{
              color: theme.palette.mode === "dark" ? "#90caf9" : "#007bff",
              textDecoration: "none",
            }}
          >
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
