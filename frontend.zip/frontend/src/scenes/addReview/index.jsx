import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Snackbar,
  Alert,
} from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useNavigate } from "react-router-dom";
import { useAuthContext } from "../../hooks/useAuthContext";
import Header from "../../components/Header";
import { usePost } from "../../hooks/usePost";

const AddReview = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { insertPost } = usePost();


  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("success");

  
  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  const handleFormSubmit = async (values, { resetForm }) => {
    try {
      const result = await insertPost(values.review, user.user[0].userId, values.paperId, user.token, user.user[0].username);

      if (result?.error) {
       
        setSnackbarMessage("Paper with the given ID does not exist.");
        setSnackbarSeverity("error");
        setSnackbarOpen(true);
        return;
      }

      
      setSnackbarMessage("Successfully added the review!");
      setSnackbarSeverity("success");
      setSnackbarOpen(true);

      resetForm(); 
    } catch (error) {
      console.error("Error adding review:", error);
      setSnackbarMessage("An error occurred while adding the review.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
    }
  };

  return (
    <Box m="20px">
      <Header title="ADD REVIEW" subtitle="Add Review on a Paper" />

      <Formik
        initialValues={{
          paperId: "",
          review: "",
        }}
        validationSchema={validationSchema}
        onSubmit={handleFormSubmit}
      >
        {({
          values,
          errors,
          touched,
          handleBlur,
          handleChange,
          handleSubmit,
        }) => (
          <form onSubmit={handleSubmit}>
            <Box
              display="grid"
              gap="20px"
              gridTemplateColumns="repeat(4, minmax(0, 1fr))"
              sx={{
                "& > div": { gridColumn: isNonMobile ? undefined : "span 4" },
              }}
            >
              <TextField
                fullWidth
                variant="filled"
                label="Paper ID"
                name="paperId"
                type="text"
                value={values.paperId}
                onBlur={handleBlur}
                onChange={handleChange}
                error={!!touched.paperId && !!errors.paperId}
                helperText={touched.paperId && errors.paperId}
                sx={{ gridColumn: "span 4" }}
              />
              <TextField
                fullWidth
                variant="filled"
                label="Review"
                name="review"
                type="text"
                value={values.review}
                onBlur={handleBlur}
                onChange={handleChange}
                error={!!touched.review && !!errors.review}
                helperText={touched.review && errors.review}
                multiline
                rows={15} 
                sx={{ gridColumn: "span 4" }}
              />
            </Box>

            <Box display="flex" justifyContent="end" mt="20px">
              <Button
                type="submit"
                color="secondary"
                variant="contained"
                size="large"
              >
                SUBMIT
              </Button>
            </Box>
          </form>
        )}
      </Formik>

      
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={snackbarSeverity}
          sx={{ width: "100%" }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};


const validationSchema = yup.object().shape({
  paperId: yup.string().required("Paper ID is required"),
  review: yup.string().required("Review is required")
});

export default AddReview;
