import React, { useState, useEffect, useCallback } from "react";
import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useConference } from "../../hooks/useConference";
import { usePaper } from "../../hooks/usePaper";
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';

const ViewPapers = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { user } = useAuthContext();
  const { getConfByAuthor } = useConference();
  const { getPapersByConf } = usePaper();

  const [papers, setPapers] = useState([]); 
  const [isLoading, setIsLoading] = useState(true); 

  const navigate = useNavigate();

  const handleNavigate = (paperId) => {
    navigate(`/reviews/${paperId}`);
  };

  const fetchPapers = useCallback(async () => {
    if (!user || !user.token) return; 

    try {
      setIsLoading(true);
      
      const conferences = await getConfByAuthor(user.user[0].username, user.token);
      const conferenceIds = conferences.map((conf) => conf.conferenceId);

      console.log("Fetched Conferences:", conferences);

      
      const allPapers = [];
      for (const conferenceId of conferenceIds) {
        const papers = await getPapersByConf(conferenceId, user.token);
        allPapers.push(
          ...papers.map((paper) => ({
            ...paper,
            conferenceTitle: conferences.find((conf) => conf.conferenceId === conferenceId)?.title || "Unknown",
          }))
        );
      }

      setPapers(allPapers); 
      console.log("Fetched Papers:", allPapers);
    } catch (error) {
      console.error("Error fetching papers:", error);
    } finally {
      setIsLoading(false);
    }
  }, [user, getConfByAuthor, getPapersByConf]);

  useEffect(() => {
    fetchPapers();
  }, []);

  
  const rows = papers.map((paper) => ({
    id: paper.paperId, 
    title: paper.title,
    abstract: paper.abstract,
    conference: paper.conferenceTitle,
  }));

  const columns = [
    { field: "id", headerName: "ID", flex: 0.5 },
    { field: "title", headerName: "Title", flex: 1 },
    { field: "abstract", headerName: "Abstract", flex: 2 },
    { field: "conference", headerName: "Conference", flex: 1 },
    {
      field: "reviews",
      headerName: "Reviews",
      flex: 1,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <Button
          variant="contained"
          color="primary"
          onClick={() => handleNavigate(params.id)}
        >
          See the reviews
        </Button>
      ),
    },
  ];

  return (
    <Box m="20px">
      <Header title="PAPERS" subtitle="List of Papers from All Conferences" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <DataGrid
            rows={rows}
            columns={columns}
            components={{ Toolbar: GridToolbar }}
          />
        )}
      </Box>
    </Box>
  );
};

export default ViewPapers;
