import React, { useState, useEffect, useCallback } from "react";
import {
  Box,
  Button,
  TextField,
  FormControl,
  Select,
  MenuItem,
  InputLabel,
  Snackbar,
  Alert,
} from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import { useAuthContext } from "../../hooks/useAuthContext";
import { useConference } from "../../hooks/useConference";
import { usePaper } from "../../hooks/usePaper";
import * as pdfjsLib from 'pdfjs-dist/build/pdf';
import Header from "../../components/Header";

pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

const AddPaper = () => {
  const { user } = useAuthContext();
  const { getConfByAuthor } = useConference();
  const { insertPaper } = usePaper();
  const [conferences, setConferences] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("success");
  const [isLoading, setIsLoading] = useState(true);
  const [file, setFile] = useState(null);

  const fetchConferences = useCallback(async () => {
    if (!user || !user.user || !user.token) return;

    try {
      setIsLoading(true);
      const data = await getConfByAuthor(user.user[0].username, user.token);
      setConferences(data || []);
    } catch (error) {
      console.error("Failed to fetch conferences:", error);
    } finally {
      setIsLoading(false);
    }
  }, [user, getConfByAuthor]);

  useEffect(() => {
    fetchConferences();
  }, []);

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  const validationSchema = yup.object().shape({
    title: yup.string().required("Title is required"),
    abstract: yup.string().required("Abstract is required"),
    conferenceId: yup.string().required("Conference selection is required"),
  });

  const extractTextFromPDF = async (pdfFile, setValues) => {
    const loadingTask = pdfjsLib.getDocument(URL.createObjectURL(pdfFile));
    const pdf = await loadingTask.promise;
    const page = await pdf.getPage(1);
    const textContent = await page.getTextContent();
    const fullText = textContent.items.map(item => item.str).join(' ');

    const titleEnd = fullText.indexOf("Abstract");
    const title = titleEnd !== -1 ? fullText.substring(0, titleEnd).trim() : "";

    const abstractStart = fullText.indexOf("Abstract");
    const abstractEnd = fullText.indexOf("Introduction");
    const abstract = abstractStart !== -1 && abstractEnd !== -1
      ? fullText.substring(abstractStart + 8, abstractEnd).trim()
      : "";

    setValues(prev => ({ ...prev, title, abstract }));
  };

  return (
    <Box m="20px">
      <Header title="ADD A PAPER" subtitle="Add a New Paper to a Conference" />
      
      <Formik
        initialValues={{ title: "", abstract: "", conferenceId: "" }}
        validationSchema={validationSchema}
        onSubmit={async (values, { resetForm }) => {
          try {
            const result = await insertPaper(values.conferenceId, values.title, values.abstract, user.token);

            if (result?.error) {
              setSnackbarMessage("Paper with this title already exists");
              setSnackbarSeverity("error");
              setSnackbarOpen(true);
              return;
            }

            setSnackbarMessage("Successfully added the papper!");
            setSnackbarSeverity("success");
            setSnackbarOpen(true);
            resetForm();
          } catch (error) {
            console.error("Error adding reviewer:", error);
            setSnackbarMessage("An error occurred while adding the papper.");
            setSnackbarSeverity("error");
            setSnackbarOpen(true);
          }
        }}
      >
        {({ values, errors, touched, handleBlur, handleChange, handleSubmit, setValues }) => (
          <form onSubmit={handleSubmit}>
            <Box display="grid" gap="30px" gridTemplateColumns="repeat(4, minmax(0, 1fr))" sx={{ "& > div": { gridColumn: "span 4" } }}>
              <TextField fullWidth variant="filled" type="text" label="Paper Title" onBlur={handleBlur} onChange={handleChange} value={values.title} name="title" error={!!touched.title && !!errors.title} helperText={touched.title && errors.title} sx={{ gridColumn: "span 4" }} />
              <TextField fullWidth variant="filled" type="text" label="Abstract" onBlur={handleBlur} onChange={handleChange} value={values.abstract} name="abstract" error={!!touched.abstract && !!errors.abstract} helperText={touched.abstract && errors.abstract} sx={{ gridColumn: "span 4" }} />
              <FormControl fullWidth variant="filled" sx={{ gridColumn: "span 4" }}>
                <InputLabel id="conference-label">Conference</InputLabel>
                <Select labelId="conference-label" value={values.conferenceId} name="conferenceId" onChange={handleChange} error={!!touched.conferenceId && !!errors.conferenceId}>
                  <MenuItem value=""><em>None</em></MenuItem>
                  {conferences.map(conf => (<MenuItem key={conf.conferenceId} value={conf.conferenceId}>{conf.title}</MenuItem>))}
                </Select>
              </FormControl>
            </Box>
            <Box display="flex" justifyContent="space-between" mt="20px">
              <input type="file" accept="application/pdf" onChange={e => { setFile(e.target.files[0]); extractTextFromPDF(e.target.files[0], setValues); }} />
              <Button type="submit" color="secondary" variant="contained">Add Paper</Button>
            </Box>
          </form>
        )}
      </Formik>
      <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose} anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
        <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: "100%" }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AddPaper;