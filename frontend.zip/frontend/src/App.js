import { useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Topbar from "./scenes/global/Topbar";
import Sidebar from "./scenes/global/Sidebar";
import Dashboard from "./scenes/dashboard";
import Team from "./scenes/team";
import Addpaper from "./scenes/addpaper";
import UploadPaper from "./scenes/uploadPaper";
import ViewPaper from "./scenes/viewPaper";
import CreateConference from "./scenes/createConference";
import Conferences from "./scenes/conferences";
import Bar from "./scenes/bar";
import Profile from "./scenes/profile";
import Pie from "./scenes/pie";
import ABOUT from "./scenes/about";
import Login from "./scenes/login";
import AddReviewer from "./scenes/addReviewer";
import UploadReviewers from "./scenes/uploadReviewers";
import Reviews from "./scenes/reviews";
import AddReview from "./scenes/addReview";
import Register from "./scenes/register";
import Recommendation from "./scenes/recommendation";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { ColorModeContext, useMode } from "./theme";
import Calendar from "./scenes/calendar/calendar";


function App() {
  const [theme, colorMode] = useMode();
  const [isSidebar, setIsSidebar] = useState(true);
  const location = useLocation();

  
  const isLoginPage = location.pathname === "/" || location.pathname === "/login" || location.pathname === "/register";

  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <div className="app">
          
          {!isLoginPage && <Sidebar isSidebar={isSidebar} />}
          <main className="content">
           
            {!isLoginPage && <Topbar setIsSidebar={setIsSidebar} />}
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/" element={<Login />} />
              <Route path="/conferences" element={<Conferences />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/team" element={<Team />} />
              <Route path="/createConference" element={<CreateConference />} />
              <Route path="/addReviewer" element={<AddReviewer />} />
              <Route path="/uploadReviewers" element={<UploadReviewers />} />
              <Route path="/reviews" element={<Reviews />} />
              <Route path="/reviews/:id" element={<Reviews />} />
              <Route path="/addpaper" element={<Addpaper />} />
              <Route path="/uploadPaper" element={<UploadPaper />} />
              <Route path="/viewPaper" element={<ViewPaper />} />
              <Route path="/recommendation/:id" element={<Recommendation />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/addReview" element={<AddReview />} />
              <Route path="/bar" element={<Bar />} />
              <Route path="/pie" element={<Pie />} />
              <Route path="/about" element={<ABOUT />} />
              <Route path="/calendar" element={<Calendar />} />
            </Routes>
          </main>
        </div>
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default App;
