import { createContext, useReducer } from 'react'

export const PostsContext = createContext();


export const postsReducer = (state, action) => {
  switch (action.type) {
    
    case 'SET_POSTS': 
     
      console.log("action.payload SET_POSTS: " + action.payload);
      return {
        posts: action.payload
      }
    case 'CREATE_POSTS':
      
      console.log("action.payload CREATE_POSTS: " + action.payload + " state.posts:  " + state.posts);
      return {
        posts: [action.payload, ...state.posts]
      }
    case 'DELETE_POST':
      return {
        posts: state.posts.filter((w) => w._id !== action.payload._id)
      }
    default:
      return state
  }
}

export const PostsContextProvider = ({ children }) => {
  
  const [state, dispatch] = useReducer(postsReducer, {
    posts: null
  });

  console.log("State 38 line PostsContext:  " + state);

  return (
    <PostsContext.Provider value={{...state, dispatch}}>
      { children }
    </PostsContext.Provider>
  )
}


