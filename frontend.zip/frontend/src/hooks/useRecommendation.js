import { useState } from 'react';
import { useAuthContext } from './useAuthContext';

// To register the user
export const useRecommendation = () => {
    const [error, setError] = useState(null)
    const [isLoading, setIsLoading] = useState(null)
    const { dispatch } = useAuthContext()

    const recommendation = async (conferenceId, token) => {
        setIsLoading(true)
        setError(null)

        console.log("Hiiiiiiii2222222");

        const response = await fetch('/api/recommendation/getRec', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ conferenceId }) // in server side we use body.firstname, etc
        })

        const json = await response.json();

        console.log("useRec json: ", json);

        if (!response.ok) {
            setIsLoading(false)
            setError(json.error)
        }

        if (response.ok) {
            // update loading state
            setIsLoading(false)

            return json;
        }
    }

    const recommendationReviewer = async (reviewer, conferenceId, token) => {
        setIsLoading(true)
        setError(null)

        console.log("Hiiiiiiii2222222");

        const response = await fetch('/api/recommendation/getRecRev', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ reviewer, conferenceId }) 
        })

        const json = await response.json();

        console.log("useRec json: ", json);

        if (!response.ok) {
            setIsLoading(false)
            setError(json.error)
        }

        if (response.ok) {
           
            setIsLoading(false)

            return json;
        }
    }

    const startRecommendation = async (conferenceId, token) => {
        setIsLoading(true)
        setError(null)

        console.log("Hiiiiiiii2222222");

        const response = await fetch('/api/recommendation/startRec', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ conferenceId }) 
        })

        const json = await response.json();

        console.log("useRec json: ", json);

        if (!response.ok) {
            setIsLoading(false)
            setError(json.error)
        }

        if (response.ok) {
            
            setIsLoading(false)

            return json;
        }
    }

    return { recommendation, recommendationReviewer, startRecommendation, isLoading, error }
}