import {useState} from "react";
import {useAuthContext} from "./useAuthContext";

export const usePost = () =>{
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(null);
    const { dispatch } = useAuthContext();

    const insertPost = async (post, reviewerId, paperId, token, username) => {
        setIsLoading(true)
        setError(null)

        const response = await fetch('/api/post/insertPost', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ post, reviewerId, paperId, username }) 
        })
        
        const json = await response.json()

        console.log(json);

        if (!response.ok) {
            
             setIsLoading(false);
             setError(json.error || "An error occurred"); 
             return { error: json.error || "Paper with the given ID does not exist" }; 
        }
        if (response.ok) {
            
            setIsLoading(false)

            return json;
        }
    }

    const getUserByPaper = async (paperId, token) => {
        setIsLoading(true);
        setError(null);

        const response = await fetch('/api/post/getPosts', {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ paperId })
        })

        const json = await response.json();

        console.log("53->", json);

        if (!response.ok) {
            setIsLoading(false)
            setError(json.error)
        }
        if (response.ok) {
            setIsLoading(false)

            return json;
        }
    }

    const getPostsbyUser = async (userId, token) => {
        setIsLoading(true);
        setError(null);

        const response = await fetch('/api/post/getPostsbyUser', {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ userId })
        })

        const json = await response.json();

        console.log("53->", json);

        if (!response.ok) {
            setIsLoading(false)
            setError(json.error)
        }
        if (response.ok) {
            setIsLoading(false)

            return json;
        }
    }

    return { insertPost, getUserByPaper, getPostsbyUser, isLoading, error }
}
