import { useState, useCallback } from 'react';
import { useAuthContext } from './useAuthContext';


export const useUsers = () => {
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const { user } = useAuthContext(); 

 
    const getAllUsers = useCallback(async () => {
        if (!user || !user.token) {
            setError('Unauthorized access: Missing token');
            return [];
        }

        setIsLoading(true);
        setError(null);

        try {
          const response = await fetch(`/api/user/allUsers?username=${user.user[0].username}`, {
            method: 'GET', 
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${user.token}`, 
            },
        });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to fetch users');
            }

            const data = await response.json();
            setIsLoading(false);
            return data; 
        } catch (err) {
            setIsLoading(false);
            setError(err.message);
            console.error('Error fetching users:', err);
            return []; 
        }
    }, [user]); 

    
    const editUser = useCallback(
        async (userDetails) => {
          if (!user || !user.token) {
            setError("Unauthorized access: Missing token");
            return null;
          }
      
          setIsLoading(true);
          setError(null);
      
          try {
            const response = await fetch("/api/user/edit", {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${user.token}`,
              },
              body: JSON.stringify(userDetails),
            });
      
            if (!response.ok) {
              const errorData = await response.json();
              throw new Error(errorData.error || "Failed to update profile");
            }
      
            const { user: updatedUser } = await response.json(); 
            setIsLoading(false);
            return updatedUser;
          } catch (err) {
            setIsLoading(false);
            setError(err.message);
            console.error("Error updating profile:", err);
            return null;
          }
        },
        [user]
      );
      

  return {getAllUsers, editUser, isLoading, error };
};