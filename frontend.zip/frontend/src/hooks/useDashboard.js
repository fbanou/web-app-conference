import { useState } from "react";
import { useAuthContext } from './useAuthContext';
export const useDashboard = () => {
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const { user } = useAuthContext(); 

    const fetchWithToken = async (url, token) => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: { Authorization: `Bearer ${token}` },
            });

            const json = await response.json();
            if (!response.ok) {
                throw new Error(json.error || 'Fetch failed');
            }
            return json.count; 
        } catch (err) {
            setError(err.message);
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    
    const getTotalReviewers = (token, username) =>
        fetchWithToken(`/api/dashboard/totalReviewers?username=${user.user[0].username}`, token);

    const getTotalReviews = (token, username) =>
        fetchWithToken(`/api/dashboard/totalReviews?username=${user.user[0].username}`, token);

    const getTotalPapers = (token, username) =>
        fetchWithToken(`/api/dashboard/totalPapers?username=${user.user[0].username}`, token);

    const getTotalConferences = (token, username) =>
        fetchWithToken(`/api/dashboard/totalConferences?username=${user.user[0].username}`, token);

    const getConferencesForReviewer = (token, username) =>
        fetchWithToken(`/api/dashboard/totalConferencesForReviewer?username=${user.user[0].username}`, token);

    return { getTotalReviewers, getTotalPapers, getTotalConferences, getTotalReviews, getConferencesForReviewer, isLoading, error };
};
