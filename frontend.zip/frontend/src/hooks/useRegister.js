import { useState } from 'react';
import { useAuthContext } from './useAuthContext';

// To register the user
export const useRegister = (firstName, lastName, email, phone, username, password, role) => {
    const [error, setError] = useState(null)
    const [isLoading, setIsLoading] = useState(null)
    const { dispatch } = useAuthContext()

    const register = async (firstName, lastName, email, phone, username, password, role) => {
        setIsLoading(true)
        setError(null)

        const response = await fetch('/api/user/register', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ firstName, lastName, email, phone, username, password, role }) 
        })
        const json = await response.json()

        console.log("lets see: ", json);

        if (!response.ok) {
            setIsLoading(false)
            setError(json.error)
        }
        if (response.ok) {
            
            localStorage.setItem('userConf', JSON.stringify(json))

            
            dispatch({type: 'LOGIN', payload: json})

            
            setIsLoading(false)
        }
    }

    return { register, isLoading, error }
}