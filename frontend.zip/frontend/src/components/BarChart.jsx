import React, { useEffect, useState, useCallback } from "react";
import { Box, CircularProgress, Typography } from "@mui/material";
import { useTheme } from "@mui/material";
import { BarChart } from "@mui/x-charts/BarChart";
import { tokens } from "../theme";
import { useAuthContext } from "../hooks/useAuthContext";
import { useConference } from "../hooks/useConference";
import { usePost } from "../hooks/usePost";
import { useUsers } from "../hooks/useUsers";

const MuiBarChart = ({ isDashboard }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { user } = useAuthContext();
  const { getConfByAuthor, getConfByReviewer } = useConference();
  const { getAllUsers } = useUsers();
  const { getPostsbyUser } = usePost();

  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchConferences = useCallback(async () => {
    if (!user || !user.user || !user.token) return;

    try {
      setIsLoading(true);
      let conferences = [];
      let reviewers = [];

      if (user.user[0].role === "admin") {
        conferences = await getConfByAuthor(user.user[0].username, user.token);
        reviewers = await getAllUsers();

        const formattedData = conferences.map((conf) => {
          const reviewersForConf = reviewers.filter((reviewer) =>
            reviewer.conferenceTitles?.includes(conf.title)
          );

          return {
            conference: conf.acronym,
            value: reviewersForConf.length,
          };
        });

        setData(formattedData);
      } else if (user.user[0].role === "reviewer") {
        conferences = await getConfByReviewer(user.user[0].email, user.token);
        reviewers = await getPostsbyUser(user.user[0].userId, user.token);

        const reviewCounts = reviewers.reduce((acc, post) => {
          acc[post.conference] = (acc[post.conference] || 0) + 1;
          return acc;
        }, {});

        const formattedData = conferences.map((conference) => ({
          conference: conference.acronym,
          value: reviewCounts[conference.acronym] || 0,
        }));

        setData(formattedData);
      }
    } catch (error) {
      console.error("Failed to fetch data:", error);
    } finally {
      setIsLoading(false);
    }
  }, [user, getConfByAuthor, getConfByReviewer, getAllUsers, getPostsbyUser]);

  useEffect(() => {
    fetchConferences();
  }, []);

  return isLoading ? (
    <Box display="flex" justifyContent="center" alignItems="center" height="300px">
      <CircularProgress />
    </Box>
  ) : (
    <BarChart
      dataset={data}
      xAxis={[{ scaleType: "band", dataKey: "conference" }]}
      series={[
        {
          dataKey: "value",
          label: user?.user[0]?.role === "admin" ? "Reviewers" : "Reviews",
        },
      ]}
      colors={[colors.greenAccent[500]]}
    />
  );
};

export default MuiBarChart;
