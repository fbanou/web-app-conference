import React, { useEffect, useState, useCallback } from "react";
import { ResponsivePie } from "@nivo/pie";
import { tokens } from "../theme";
import { useTheme } from "@mui/material";
import { useAuthContext } from "../hooks/useAuthContext";
import { useConference } from "../hooks/useConference";

const areaMapping = {
  6: "Accounting and Finance",
  8: "Art and Humanities",
  11: "Biological Sciences",
  5: "Business and Management",
  3: "Chemistry",
  23: "Civil Engineering",
  1: "Computing",
  12: "Earth and Environmental Sciences",
  15: "Economics",
  16: "Education Science",
  17: "Energy",
  2: "Engineering",
  13: "Genomics and Bioinformatics",
  10: "Health Sciences",
  7: "Language and Linguistics",
  14: "Materials Science",
  19: "Mathematics and Statistics",
  24: "Mechanical Engineering",
  4: "Physics",
  9: "Social Sciences",
  18: "Technology",
};


const PieChart = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { user } = useAuthContext();
  const { getConfByAuthor } = useConference();

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchConferences = useCallback(async () => {
    if (!user || user.user[0].role !== "admin") {
      setError("Access denied. Only admins can view this chart.");
      setLoading(false);
      return;
    }

    try {
      const conferences = await getConfByAuthor(user.user[0].username, user.token);

    
      const areaCounts = conferences.reduce((acc, conference) => {
        const areaName = areaMapping[conference.primaryarea];
        if (areaName) {
          acc[areaName] = (acc[areaName] || 0) + 1;
        }
        return acc;
      }, {});

     
      const formattedData = Object.entries(areaCounts).map(([area, count]) => ({
        id: area,
        label: area,
        value: count,
      }));

      
      setData((prevData) =>
        JSON.stringify(prevData) === JSON.stringify(formattedData) ? prevData : formattedData
      );
    } catch (err) {
      console.error("Error fetching or processing conferences:", err);
      setError("Failed to fetch data.");
    } finally {
      setLoading(false);
    }
  }, [user, getConfByAuthor]);


  useEffect(() => {
    fetchConferences();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <ResponsivePie
      data={data}
      theme={{
        axis: {
          domain: { line: { stroke: colors.grey[100] } },
          legend: { text: { fill: colors.grey[100] } },
          ticks: {
            line: { stroke: colors.grey[100], strokeWidth: 1 },
            text: { fill: colors.grey[100] },
          },
        },
        legends: { text: { fill: colors.grey[100] } },
      }}
      margin={{ top: 40, right: 80, bottom: 80, left: 80 }}
      innerRadius={0.5}
      padAngle={0.7}
      cornerRadius={3}
      activeOuterRadiusOffset={8}
      borderColor={{
        from: "color",
        modifiers: [["darker", 0.2]],
      }}
      arcLinkLabelsSkipAngle={10}
      arcLinkLabelsTextColor={colors.grey[100]}
      arcLinkLabelsThickness={2}
      arcLinkLabelsColor={{ from: "color" }}
      enableArcLabels={false}
      arcLabelsRadiusOffset={0.4}
      arcLabelsSkipAngle={7}
      arcLabelsTextColor={{
        from: "color",
        modifiers: [["darker", 2]],
      }}
      defs={[
        {
          id: "dots",
          type: "patternDots",
          background: "inherit",
          color: "rgba(255, 255, 255, 0.3)",
          size: 4,
          padding: 1,
          stagger: true,
        },
        {
          id: "lines",
          type: "patternLines",
          background: "inherit",
          color: "rgba(255, 255, 255, 0.3)",
          rotation: -45,
          lineWidth: 6,
          spacing: 10,
        },
      ]}
    />
  );
};

export default PieChart;
